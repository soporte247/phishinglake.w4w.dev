<div align='center'>
    <h1><b><i>Phishing Lake</i></b></h1>
    <img src="./assets/img/banner.png" alt="Phishing Lake Banner" width="50%" align="center">
    <br/>
    <br/>
    <h6>A simple web app to learn about cybersecurity-related phishing attacks</h6>
    <hr/>
</div>


